<?php 
//chạy đến thư mục student trong dự án
header('location:student');